# Patent-Managemnet
This project is created using MERN stack that focus on CRUD operations on the Data in Database.This project is developed for my college to store their patents,conferences,projects details etc.,
